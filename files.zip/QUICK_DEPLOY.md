# 🚀 Quick Deploy Guide

Get your portfolio live in 5 minutes!

## Step 1: Get Your Files Ready (2 min)

Create a folder called `portfolio` and add these files:
- `index.html` (download from outputs)
- `bio.html` (download from outputs)
- `my_photo.jpg` (your photo)
- Logo images (optional)

## Step 2: Create GitHub Repository (1 min)

1. Go to https://github.com/new
2. Repository name: `portfolio`
3. Make it **Public**
4. Click **Create repository**

## Step 3: Upload Files (1 min)

### Option A: Drag and Drop (Easiest)
1. On your new repository page, click **uploading an existing file**
2. Drag all your files into the browser
3. Write "Initial commit" in the box
4. Click **Commit changes**

### Option B: Command Line
```bash
cd /path/to/your/portfolio
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/portfolio.git
git push -u origin main
```

## Step 4: Enable GitHub Pages (1 min)

1. Click **Settings** in your repository
2. Click **Pages** in the left sidebar
3. Under **Source**, select **main** branch
4. Click **Save**
5. Wait 2-3 minutes

## Step 5: View Your Site! 🎉

Your site is now live at:
```
https://YOUR_USERNAME.github.io/portfolio/
```

Replace `YOUR_USERNAME` with your actual GitHub username.

---

## 🔗 Custom Domain (Optional)

Want to use your own domain like `timapidlisnyi.com`?

1. Buy a domain from Namecheap, GoDaddy, etc.
2. In your repository Settings → Pages → Custom domain
3. Enter your domain name
4. In your domain registrar, add these DNS records:
   ```
   Type: A
   Name: @
   Value: 185.199.108.153
   
   Type: A
   Name: @
   Value: 185.199.109.153
   
   Type: A
   Name: @
   Value: 185.199.110.153
   
   Type: A
   Name: @
   Value: 185.199.111.153
   
   Type: CNAME
   Name: www
   Value: YOUR_USERNAME.github.io
   ```
5. Wait 24-48 hours for DNS to propagate

---

## 🆘 Having Issues?

**Files uploaded but site not working?**
- Make sure `index.html` is in the root folder (not in a subfolder)
- Wait 5-10 minutes for GitHub Pages to build

**404 Error?**
- Check that repository is **Public** (Settings → General → Danger Zone)
- Verify the URL includes your username

**Images not showing?**
- Check file names are exact (case-sensitive)
- Make sure images are in the root folder with index.html

**Still stuck?**
See the full README.md for detailed troubleshooting.

---

**That's it! Your portfolio is live! 🎊**

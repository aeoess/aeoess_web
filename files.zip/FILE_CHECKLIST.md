# Portfolio Website - File Checklist

Use this checklist to ensure you have all necessary files before deploying to GitHub.

## ✅ Core Files (REQUIRED)

- [ ] `index.html` - Main homepage
- [ ] `bio.html` - Extended biography page
- [ ] `README.md` - GitHub documentation

## 📸 Images (REQUIRED)

- [ ] `my_photo.jpg` - Your profile photo
- [ ] `evatar_logo.PNG` - Evatar.ai company logo
- [ ] `OFNATURE_LOGO.PNG` - ofNature company logo
- [ ] `peropero_logo.png` - Pero Pero company logo

**Note:** If you don't have company logos, they will appear as colored placeholder boxes.

## 📂 Work History Pages (RECOMMENDED)

Create a folder called `mywork/` and include:

- [ ] `mywork/index.html` - Work history main page
- [ ] `mywork/evatar.html`
- [ ] `mywork/elegatto.html`
- [ ] `mywork/ofnature.html`
- [ ] `mywork/peropero.html`
- [ ] `mywork/authoritytech.html`
- [ ] `mywork/njf.html`
- [ ] `mywork/hayi.html`
- [ ] `mywork/allset.html`
- [ ] `mywork/legrem.html`
- [ ] `mywork/amplifier-agency.html`
- [ ] `mywork/m1tv.html`
- [ ] `mywork/prompt-director.html`
- [ ] `mywork/aeoess.html`
- [ ] `mywork/sheethappens.html`
- [ ] `mywork/pickapoo.html`
- [ ] `mywork/creative-projects.html`

**Note:** If these pages don't exist yet, the main homepage will still work. Links will just lead to 404 pages.

## 🎯 Quick Start (Minimum Viable Portfolio)

If you want to deploy quickly with just the essentials:

**Minimum files needed:**
1. `index.html`
2. `bio.html`
3. `my_photo.jpg`

The site will work without logos and work detail pages, but some links won't function.

## 📋 Before You Deploy

1. [ ] All file names match exactly (case-sensitive)
2. [ ] Your profile photo is named `my_photo.jpg`
3. [ ] All files are in the correct folders
4. [ ] You've tested the site locally by opening `index.html`
5. [ ] You've reviewed the content for any personal info you want to remove

## 🔗 Useful Links to Update

Before deploying, review and update these links in `index.html`:

- [ ] Email: `tima@aeoess.com`
- [ ] LinkedIn: `https://linkedin.com/in/tymofii-pidlisnyi`
- [ ] Instagram: `https://instagram.com/tima.fey`
- [ ] Evatar.ai: `https://evatar.ai`
- [ ] Prompt Director: `https://prompt-director.rork.app`

## 🚀 Ready to Deploy?

If you've checked off the minimum required files, you're ready to follow the GitHub deployment instructions in README.md!

---

**Questions?**
Review the README.md for detailed deployment instructions and troubleshooting tips.
